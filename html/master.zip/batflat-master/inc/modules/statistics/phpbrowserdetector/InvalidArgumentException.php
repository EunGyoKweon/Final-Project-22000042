<?php

namespace Inc\Modules\Statistics\PHPBrowserDetector;

class InvalidArgumentException extends \InvalidArgumentException
{
}
