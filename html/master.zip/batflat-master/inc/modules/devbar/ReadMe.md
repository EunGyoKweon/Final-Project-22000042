After installing this module, you must enable `DEV_MODE` in the `inc/core/defines.php` file. Otherwise, the debugger will not appear.

To debug variable values put in the code `dump([your_variable])` function.