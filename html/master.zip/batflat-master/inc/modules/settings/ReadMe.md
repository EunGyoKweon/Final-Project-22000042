You can display settings data by using construction below:

```
{$settings.field-name}
```